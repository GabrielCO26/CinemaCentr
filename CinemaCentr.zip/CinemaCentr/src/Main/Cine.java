package Main;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Cine {
    
    private String name;
    
    public Cine(String name){
        this.name = name;
    }
    
    public void setName(String password) {
        this.name = name;
    }
    
    public String getName(){
        return name;
    }
    
}
